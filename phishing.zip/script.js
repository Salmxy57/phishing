function detectPhishing() {
  const text = document.getElementById("emailInput").value.toLowerCase();
  const resultDiv = document.getElementById("result");

  const phishingKeywords = [
    "urgent", "verify", "login", "bank", "password", "reset", "click here",
    "account suspended", "confirm your identity", "security alert"
  ];

  const phishingLinks = /(http[s]?:\/\/[^ ]*?\.(ru|cn|tk|ml|ga|cf|gq|xyz|click|top|work|zip))/g;

  let warningMessages = [];

  phishingKeywords.forEach(keyword => {
    if (text.includes(keyword)) {
      warningMessages.push(`?? Suspicious keyword: "${keyword}"`);
    }
  });

  const linkMatches = text.match(phishingLinks);
  if (linkMatches) {
    warningMessages.push(`?? Suspicious link(s) found: ${linkMatches.join(", ")}`);
  }

  if (warningMessages.length > 0) {
    resultDiv.innerHTML = `<span style="color:red;">Potential phishing detected:</span><br>${warningMessages.join("<br>")}`;
  } else {
    resultDiv.innerHTML = `<span style="color:green;">No obvious phishing signs detected.</span>`;
  }
}
